<?php
/**
 * Version metadata for the block_pluginname plugin.
 *
 * @package   block_pluginname
 * @copyright Year, You Name <your@email.address>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();
$plugin->version = 2020110900;
$plugin->requires = 2020110300;
$plugin->component = 'block_course_task';