<?php
/**
 * Languages configuration for the block_pluginname plugin.
 *
 * @package   block_pluginname
 * @copyright Year, You Name <your@email.address>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['course_task'] = 'Course Task Block';
$string['course_task'] = 'Course Task';
$string['course_task_completionnotenabledforsite'] = 'Enabled Completion For Site';
$string['course_task_completionnotenabledforcourse'] = 'Enabled Completion For Course';
$string['course_task:addinstance'] = 'Add a new Course Task block';
$string['course_task:myaddinstance'] = 'Add a new Course Task block to the My Moodle page';