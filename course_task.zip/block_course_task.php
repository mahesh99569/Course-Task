<?php
/**
 * Plugin for the block_course_task plugin.
 *
 * @package   block_course_task
 * @copyright 2022, Mahesh <mahesh99123@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
*/
class block_course_task extends block_base {
    /**
     * Initialises the block.
     *
     * @return void
     */
    public function init() {
        $this->title = get_string('course_task', 'block_course_task');
    }
    /**
     * Gets the block contents.
     *
     * @return string The block HTML.
     */
    public function get_content() {
        global $OUTPUT,$USER, $CFG, $DB;
        require_once("{$CFG->libdir}/completionlib.php");
        $systemcontext = context_system::instance();
        $user = $DB->get_record('user', array('id' => $USER->id), '*', MUST_EXIST);
        //$course = $DB->get_record('course', array('id' => $courseid), '*', MUST_EXIST);
        $currentuser = ($user->id == $USER->id);
        //$coursecontext = context_course::instance($course->id);
        $usercontext   = context_user::instance($USER->id, IGNORE_MISSING);
        
        // Check we are not trying to view guest's profile.
        if (isguestuser($user)) {
            // Can not view profile of guest - thre is nothing to see there.
            throw new \moodle_exception('invaliduserid');
        }
        if ($this->content !== null) {
            return $this->content;
        }
        $context = $this->page->context;
        $this->content = new stdClass();
		// Get the course activities for the current course
        $modinfo = get_fast_modinfo($this->page->course->id);
        $mods = $modinfo->get_cms();
        $result2 = "";
		$result2 = $DB->get_records_sql('SELECT mc.coursemoduleid,mc.userid,mc.completionstate,
		m.id,m.added as created,m.course FROM {course_modules_completion} mc
		LEFT JOIN {course_modules} m ON mc.coursemoduleid=m.id WHERE mc.userid = ? AND m.course = ?', array( $user->id ,$this->page->course->id ));
		foreach($mods as $cm) {
        	$modrec = $DB->get_record($cm->modname, array('id' => $cm->instance)); 

        	$link = html_writer::link(new moodle_url('/mod/'.$cm->modname.'/view.php', array('id' => $cm->id)), $modrec->name);
        	//$result2[$cm->id]->created;
        	$activity_status = "";
        	if( $result2[$cm->id] && $result2[$cm->id]->completionstate!=0){
        		$activity_status = " -- Completed";
        	}
        	$this->content->text .= '<div>'.$cm->id." - ".$link." - ".userdate($modrec->timecreated, get_string('strftimedatemonthabbr', 'core_langconfig')).$activity_status.'</div>';   
        	$this->content->text .="<br/>";          
        }
        return $this->content;
    }
    /**
     * Defines in which pages this block can be added.
     *
     * @return array of the pages where the block can be added.
     */
    public function applicable_formats() {
        return [
            'admin' => false,
            'site-index' => false,
            'course-view' => true,
            'mod' => false,
            'my' => false,
        ];
    }
}